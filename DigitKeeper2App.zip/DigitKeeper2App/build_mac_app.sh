#!/bin/bash
# ============================================================
#  DIGIT KEEPER 2 — macOS App Builder
#  Run this script once on your Mac to create DigitKeeper2.app
#  Usage:  chmod +x build_mac_app.sh && ./build_mac_app.sh
# ============================================================

set -e

APP_NAME="DigitKeeper2"
SCRIPT="digit_keeper2.py"
BUNDLE="${APP_NAME}.app"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║       DIGIT KEEPER 2 — macOS App Builder             ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── Check Python ────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "❌ Python3 not found. Install from https://python.org"
    exit 1
fi

PY=$(command -v python3)
echo "✅ Python: $PY ($(python3 --version))"

# ── Check / Install pygame ──────────────────────────────────
echo ""
echo "📦 Checking pygame..."
if ! python3 -c "import pygame" 2>/dev/null; then
    echo "   Installing pygame..."
    pip3 install pygame
fi
echo "✅ pygame ready"

# ── Check / Install PyInstaller ─────────────────────────────
echo ""
echo "📦 Checking PyInstaller..."
if ! command -v pyinstaller &>/dev/null; then
    echo "   Installing PyInstaller..."
    pip3 install pyinstaller
fi
echo "✅ PyInstaller ready"

# ── Build .app bundle ───────────────────────────────────────
echo ""
echo "🔨 Building ${BUNDLE}..."

# Create icon if it doesn't exist
if [ ! -f "icon.icns" ]; then
    echo "   Generating icon..."
    mkdir -p icon.iconset
    python3 - <<'ICON_PY'
import subprocess, os, math

# Generate a simple icon using Python (no pygame needed)
try:
    # Try PIL/Pillow first
    from PIL import Image, ImageDraw, ImageFont
    sizes = [16, 32, 64, 128, 256, 512, 1024]
    for size in sizes:
        img = Image.new('RGBA', (size, size), (0, 0, 0, 255))
        draw = ImageDraw.Draw(img)
        
        # Orange background circle
        margin = size // 10
        draw.ellipse([margin, margin, size-margin, size-margin], 
                     fill=(30, 30, 30, 255), outline=(255, 140, 28, 255), width=max(1, size//20))
        
        # Stick figure (orange)
        cx, cy = size // 2, size // 2
        scale = size / 64
        col = (255, 140, 28, 255)
        lw = max(1, int(2 * scale))
        
        # Head
        hr = int(8 * scale)
        draw.ellipse([cx-hr, cy-int(28*scale)-hr, cx+hr, cy-int(28*scale)+hr], 
                     outline=col, width=lw)
        # Body
        draw.line([cx, cy-int(18*scale), cx, cy+int(8*scale)], fill=col, width=lw)
        # Arms
        draw.line([cx, cy-int(6*scale), cx-int(14*scale), cy+int(2*scale)], fill=col, width=lw)
        draw.line([cx, cy-int(6*scale), cx+int(14*scale), cy+int(2*scale)], fill=col, width=lw)
        # Legs
        draw.line([cx, cy+int(8*scale), cx-int(10*scale), cy+int(28*scale)], fill=col, width=lw)
        draw.line([cx, cy+int(8*scale), cx+int(10*scale), cy+int(28*scale)], fill=col, width=lw)
        
        name = f"icon.iconset/icon_{size}x{size}.png"
        img.save(name)
        if size <= 512:
            img2 = img.resize((size*2, size*2), Image.LANCZOS)
            img2.save(f"icon.iconset/icon_{size}x{size}@2x.png")
    print("PIL icon generated")
except ImportError:
    # Fallback: create minimal PNG without PIL
    import struct, zlib
    def make_png(size, color=(255,140,28)):
        def chunk(name, data):
            c = zlib.crc32(name + data) & 0xffffffff
            return struct.pack('>I', len(data)) + name + data + struct.pack('>I', c)
        pixels = []
        for y in range(size):
            row = b'\x00'
            for x in range(size):
                # Orange square with rounded feel
                cx2 = x - size//2; cy2 = y - size//2
                r = math.sqrt(cx2**2 + cy2**2)
                if r < size//2 - 2:
                    row += bytes(color) + b'\xff'
                else:
                    row += b'\x00\x00\x00\xff'
            pixels.append(row)
        raw = b''.join(pixels)
        compressed = zlib.compress(raw)
        ihdr = struct.pack('>IIBBBBB', size, size, 8, 2, 0, 0, 0)
        data  = b'\x89PNG\r\n\x1a\n'
        data += chunk(b'IHDR', ihdr)
        data += chunk(b'IDAT', compressed)
        data += chunk(b'IEND', b'')
        return data
    for size in [16,32,64,128,256,512,1024]:
        with open(f"icon.iconset/icon_{size}x{size}.png","wb") as f:
            f.write(make_png(size))
    print("Fallback icon generated")
ICON_PY
    iconutil -c icns icon.iconset -o icon.icns 2>/dev/null || true
    rm -rf icon.iconset
fi

# PyInstaller spec
cat > ${APP_NAME}.spec <<SPEC
# -*- mode: python ; coding: utf-8 -*-
block_cipher = None

a = Analysis(
    ['${SCRIPT}'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=['pygame', 'pygame.font', 'pygame.mixer'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='${APP_NAME}',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='icon.icns',
)

app = BUNDLE(
    exe,
    name='${APP_NAME}.app',
    icon='icon.icns',
    bundle_identifier='com.digitkeeper.game',
    info_plist={
        'CFBundleName': 'Digit Keeper 2',
        'CFBundleDisplayName': 'Digit Keeper 2',
        'CFBundleVersion': '2.0.0',
        'CFBundleShortVersionString': '2.0',
        'NSHighResolutionCapable': True,
        'LSMinimumSystemVersion': '10.13.0',
        'CFBundleDocumentTypes': [],
        'NSHumanReadableCopyright': 'Digit Keeper 2 — Math Battle Game',
    },
)
SPEC

pyinstaller --clean --noconfirm ${APP_NAME}.spec

# ── Result ──────────────────────────────────────────────────
echo ""
if [ -d "dist/${BUNDLE}" ]; then
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║   ✅  BUILD SUCCESSFUL!                               ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo ""
    echo "   Your app:  $(pwd)/dist/${BUNDLE}"
    echo ""
    echo "   To install: drag DigitKeeper2.app to /Applications"
    echo ""
    
    # Open the dist folder
    open dist/ 2>/dev/null || true
else
    echo "❌ Build failed — check output above"
    exit 1
fi
