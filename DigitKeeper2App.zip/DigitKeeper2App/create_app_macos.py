#!/usr/bin/env python3
"""
DIGIT KEEPER 2 — Manual macOS .app Creator
==========================================
This script creates a proper macOS .app bundle WITHOUT PyInstaller.
The app uses your installed Python, so it's lightweight and fast.

Run:  python3 create_app_macos.py
"""

import os
import sys
import stat
import shutil

APP_NAME    = "Digit Keeper 2"
BUNDLE_NAME = "DigitKeeper2.app"
SCRIPT_NAME = "digit_keeper2.py"
BUNDLE_ID   = "com.digitkeeper.game"
VERSION     = "2.0"

def find_python():
    """Find the best Python path to embed in the app."""
    for path in [sys.executable, "/usr/local/bin/python3",
                 "/usr/bin/python3", "/opt/homebrew/bin/python3"]:
        if os.path.exists(path):
            return path
    return sys.executable

def check_pygame():
    try:
        import pygame
        return True
    except ImportError:
        return False

def create_app():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    game_script = os.path.join(script_dir, SCRIPT_NAME)

    if not os.path.exists(game_script):
        print(f"ERROR: {SCRIPT_NAME} not found in {script_dir}")
        sys.exit(1)

    print(f"\n╔══════════════════════════════════════════════╗")
    print(f"║   Creating {APP_NAME}.app               ║")
    print(f"╚══════════════════════════════════════════════╝\n")

    # Check pygame
    if not check_pygame():
        print("pygame not found — installing...")
        os.system(f"{sys.executable} -m pip install pygame")
        if not check_pygame():
            print("ERROR: Could not install pygame. Run: pip3 install pygame")
            sys.exit(1)
    print("✅ pygame found")

    python_path = find_python()
    print(f"✅ Python: {python_path}")

    # Build bundle structure
    bundle_path    = os.path.join(script_dir, BUNDLE_NAME)
    contents_path  = os.path.join(bundle_path, "Contents")
    macos_path     = os.path.join(contents_path, "MacOS")
    resources_path = os.path.join(contents_path, "Resources")

    # Clean existing
    if os.path.exists(bundle_path):
        shutil.rmtree(bundle_path)
        print(f"🗑  Removed old {BUNDLE_NAME}")

    os.makedirs(macos_path, exist_ok=True)
    os.makedirs(resources_path, exist_ok=True)
    print(f"📁 Created bundle structure")

    # Copy game script into Resources
    dest_script = os.path.join(resources_path, SCRIPT_NAME)
    shutil.copy2(game_script, dest_script)
    print(f"📋 Copied {SCRIPT_NAME}")

    # Copy save file if it exists
    save_file = os.path.join(script_dir, "digit_keeper_save.json")
    if os.path.exists(save_file):
        shutil.copy2(save_file, os.path.join(resources_path, "digit_keeper_save.json"))
        print("💾 Copied save file")

    # Create the launcher executable
    launcher_path = os.path.join(macos_path, "DigitKeeper2")
    launcher_content = f"""#!/bin/bash
# Digit Keeper 2 Launcher
# Finds Python and runs the game from Resources

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
RESOURCES="$SCRIPT_DIR/../Resources"
GAME="$RESOURCES/{SCRIPT_NAME}"
SAVE="$RESOURCES/digit_keeper_save.json"

# Find Python with pygame
PYTHON=""
for py in "{python_path}" /usr/local/bin/python3 /opt/homebrew/bin/python3 /usr/bin/python3; do
    if [ -x "$py" ] && "$py" -c "import pygame" 2>/dev/null; then
        PYTHON="$py"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    osascript -e 'display alert "Digit Keeper 2" message "Python with pygame not found.\\n\\nOpen Terminal and run:\\n  pip3 install pygame" as critical'
    exit 1
fi

# Set save file path to Resources so it persists
export DK_SAVE_DIR="$RESOURCES"

cd "$RESOURCES"
exec "$PYTHON" "$GAME"
"""
    with open(launcher_path, "w") as f:
        f.write(launcher_content)

    # Make launcher executable
    st = os.stat(launcher_path)
    os.chmod(launcher_path, st.st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    print(f"✅ Created launcher script")

    # Create Info.plist
    plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>
    <string>{APP_NAME}</string>
    <key>CFBundleDisplayName</key>
    <string>{APP_NAME}</string>
    <key>CFBundleIdentifier</key>
    <string>{BUNDLE_ID}</string>
    <key>CFBundleVersion</key>
    <string>{VERSION}</string>
    <key>CFBundleShortVersionString</key>
    <string>{VERSION}</string>
    <key>CFBundleExecutable</key>
    <string>DigitKeeper2</string>
    <key>CFBundleIconFile</key>
    <string>AppIcon</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleSignature</key>
    <string>DK2G</string>
    <key>LSMinimumSystemVersion</key>
    <string>10.13</string>
    <key>NSHighResolutionCapable</key>
    <true/>
    <key>NSHumanReadableCopyright</key>
    <string>Digit Keeper 2 — Math Battle Game 2025</string>
    <key>LSApplicationCategoryType</key>
    <string>public.app-category.games</string>
</dict>
</plist>
"""
    plist_path = os.path.join(contents_path, "Info.plist")
    with open(plist_path, "w") as f:
        f.write(plist_content)
    print("✅ Created Info.plist")

    # Create a simple icon using pygame (if available)
    try:
        import pygame
        import math as _math

        pygame.init()
        sizes = [16, 32, 64, 128, 256, 512, 1024]
        iconset_path = os.path.join(script_dir, "AppIcon.iconset")
        os.makedirs(iconset_path, exist_ok=True)

        for size in sizes:
            surf = pygame.Surface((size, size), pygame.SRCALPHA)
            surf.fill((0, 0, 0, 255))

            # Dark circle background
            pygame.draw.circle(surf, (20, 20, 20, 255), (size//2, size//2), size//2-2)
            pygame.draw.circle(surf, (255, 140, 28, 255), (size//2, size//2), size//2-2, max(1, size//20))

            # Stick figure (orange)
            cx, cy = size//2, size//2
            sc = size / 64
            col = (255, 140, 28, 255)
            lw = max(1, int(2*sc))

            # Head
            hr = int(8*sc)
            pygame.draw.circle(surf, col, (cx, cy-int(28*sc)), hr, lw)
            # Body
            pygame.draw.line(surf, col, (cx, cy-int(18*sc)), (cx, cy+int(8*sc)), lw)
            # Arms
            pygame.draw.line(surf, col, (cx, cy-int(6*sc)), (cx-int(14*sc), cy+int(2*sc)), lw)
            pygame.draw.line(surf, col, (cx, cy-int(6*sc)), (cx+int(14*sc), cy+int(2*sc)), lw)
            # Legs
            pygame.draw.line(surf, col, (cx, cy+int(8*sc)), (cx-int(10*sc), cy+int(28*sc)), lw)
            pygame.draw.line(surf, col, (cx, cy+int(8*sc)), (cx+int(10*sc), cy+int(28*sc)), lw)

            # "2" label
            if size >= 64:
                font = pygame.font.Font(None, max(12, int(size*0.28)))
                fs = font.render("2", True, (255, 200, 80))
                surf.blit(fs, (cx + int(10*sc), cy - int(36*sc)))

            fname = os.path.join(iconset_path, f"icon_{size}x{size}.png")
            pygame.image.save(surf, fname)
            if size <= 512:
                surf2 = pygame.transform.scale(surf, (size*2, size*2))
                pygame.image.save(surf2, os.path.join(iconset_path, f"icon_{size}x{size}@2x.png"))

        pygame.quit()

        # Convert iconset to icns
        icns_path = os.path.join(resources_path, "AppIcon.icns")
        result = os.system(f"iconutil -c icns '{iconset_path}' -o '{icns_path}' 2>/dev/null")
        shutil.rmtree(iconset_path)
        if result == 0:
            print("✅ Created app icon")
        else:
            print("⚠️  Icon conversion skipped (iconutil not available)")
    except Exception as e:
        print(f"⚠️  Icon creation skipped: {e}")

    # Done!
    print(f"\n╔══════════════════════════════════════════════╗")
    print(f"║   ✅  {BUNDLE_NAME} created!           ║")
    print(f"╚══════════════════════════════════════════════╝")
    print(f"\n   Location: {bundle_path}")
    print(f"\n   ▶ Double-click DigitKeeper2.app to play!")
    print(f"   ▶ Drag to /Applications to install permanently\n")

    # Open Finder at bundle location
    os.system(f"open -R '{bundle_path}' 2>/dev/null || true")

    return bundle_path


if __name__ == "__main__":
    if sys.platform != "darwin":
        print("This script is for macOS only.")
        print("For Windows: run build_windows.bat")
        print("For Linux:   python3 digit_keeper2.py")
        sys.exit(0)
    create_app()
