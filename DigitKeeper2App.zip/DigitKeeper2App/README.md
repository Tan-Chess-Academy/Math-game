# DIGIT KEEPER 2
## Math Battle Calculator Game

A stick figure lives inside a calculator, battles number bosses,
learns trigonometry from historical mathematicians, and builds
complex expressions using sigma, integrals, exponents, and iota.

---

## HOW TO BUILD THE APP

### macOS (creates a double-clickable .app)

1. Open **Terminal**
2. Navigate to this folder:
   ```
   cd /path/to/DigitKeeper2App
   ```
3. Run the build script:
   ```
   chmod +x build_mac_app.sh
   ./build_mac_app.sh
   ```
4. When done, a **Finder window** opens showing `DigitKeeper2.app`
5. Drag it to `/Applications` to install

**Requirements:** Python 3.8+, internet connection (first build only)

---

### Windows (creates a standalone .exe)

1. Double-click **`build_windows.bat`**
2. Wait for it to finish
3. Find **`DigitKeeper2.exe`** in the `dist\` folder
4. Double-click to play — no Python needed!

---

### Linux

```bash
pip3 install pygame pyinstaller
pyinstaller --onefile --windowed digit_keeper2.py
./dist/digit_keeper2
```

---

## JUST WANT TO PLAY RIGHT NOW?

```bash
pip3 install pygame
python3 digit_keeper2.py
```

---

## GAME CONTROLS

| Key | Action |
|-----|--------|
| `A / D` or `← →` | Walk left / right |
| `W` or `↑` | Jump |
| `0–9` | Pick up digit |
| `+ - * /` | Pick up operator |
| `J` | Pick up iota (i) |
| `)` | Pick up closing bracket |
| `Shift+8` | Pick up exponent `^` |
| `Ctrl+8` | Pick up square root `√(` |
| `S` | Pick up Sigma Σ |
| `I` | Pick up Integral ∫ |
| `SPACE` | Place symbol at cursor |
| `BACKSPACE` | Pick up nearest symbol |
| `ENTER` | Evaluate expression |
| `P` | Cycle unlocked boss symbols |
| `B` | Open Bag (boss roster + controls) |
| `G` | Mathematician Gallery |
| `T` | Trig Circle Mode (needs π) |
| `C` | Clear all |
| `Ctrl+S` | Save game |
| `Ctrl+L` | Load game |
| `ESC` | Quit |

---

## BATTLE CONTROLS

| Key | Action |
|-----|--------|
| `WASD` / Arrows | Move |
| `SPACE` | Shoot |
| `1 / 2 / 3` | Switch weapon |
| `Shift` | Raise Zero Shield (if unlocked) |
| `F` | Flick clustered shots back |
| `ESC` | Flee battle |

---

## BOSSES & UNLOCK ORDER

Evaluate these expressions to trigger each boss:

| Expression | Boss | Reward |
|------------|------|--------|
| `2+2`, `4`, `9` | Perfect Square | n² popup |
| `1+1`, `2` | TWO | 2-ops popup |
| `1-2`, `-5` | Negative | −f(x) popup |
| `1/3`, `0.5` | Rational | p/q popup |
| `22/7`, `3.14` | Irrational (π) | π popup + Trig Mode |
| `2*i`, `i**2` | Imaginary | complex popup |
| `0` | Zero | 0-shield in battles! |
| `1/0` → ∞ | Infinity | limit popup |
| `100`, `n!` large | Big Number | factorial popup |
| `math.e`, `2.718` | Euler's e | exp/log popup |
| `1.618` | Golden Ratio φ | Fibonacci popup |

---

## SAVE FILES

Save data is stored as `digit_keeper_save.json` in the same
folder as the game. Copy it to keep your progress.

---

## FEATURES

- **10 Number Bosses** — each with 3 phases, homing attacks,
  vertical sweeps, predicted aim, and bouncing shots
- **Zero Shield** — absorbs damage, recharges on flick
- **Flick/Parry** — redirect enemy cluster attacks back
- **Sigma (Σ)** — summation with custom f(n)
- **Integration (∫)** — Simpson's rule with custom f(x)
- **Trig Circle Mode** — 5 historical teachers (Aryabhatta,
  Hipparchus, Al-Battani, Euler, Pythagoras)
- **Mathematician Gallery** — 16 mathematicians unlocked by
  defeating bosses, each with historical lessons
- **Boss Popups** — compute with each boss's special power
- **Complex numbers** — full i/iota support
- **Save/Load** — progress persists across sessions
