@echo off
REM ============================================================
REM  DIGIT KEEPER 2 — Windows App Builder
REM  Creates DigitKeeper2.exe (standalone, no Python needed)
REM  Usage: Double-click this file or run in Command Prompt
REM ============================================================

echo.
echo ╔══════════════════════════════════════════════════════╗
echo ║       DIGIT KEEPER 2 — Windows App Builder           ║
echo ╚══════════════════════════════════════════════════════╝
echo.

REM Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python not found.
    echo Install from https://python.org ^(check "Add to PATH"^)
    pause
    exit /b 1
)
echo [OK] Python found

REM Install/upgrade pygame
echo.
echo Installing pygame...
pip install pygame --quiet
echo [OK] pygame ready

REM Install PyInstaller
echo.
echo Installing PyInstaller...
pip install pyinstaller --quiet
echo [OK] PyInstaller ready

REM Build
echo.
echo Building DigitKeeper2.exe...
pyinstaller --onefile --windowed --name=DigitKeeper2 digit_keeper2.py

echo.
if exist dist\DigitKeeper2.exe (
    echo ╔══════════════════════════════════════════════════════╗
    echo ║   SUCCESS! DigitKeeper2.exe created in dist\         ║
    echo ╚══════════════════════════════════════════════════════╝
    echo.
    echo    Location: %CD%\dist\DigitKeeper2.exe
    echo    Double-click the .exe to play!
    start dist\
) else (
    echo ERROR: Build failed. Check output above.
)

pause
